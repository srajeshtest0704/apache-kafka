package com.boa.training.domain;

public class Account {
	private int account_no;
	private int customer_id;
	private String account_type;
	private double balance;
	private double interestRate;

	public int getAccount_no() {
		return account_no;
	}

	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public Account(int account_no, int customer_id, String account_type, double balance, double interestRate) {
		super();
		this.account_no = account_no;
		this.customer_id = customer_id;
		this.account_type = account_type;
		this.balance = balance;
		this.interestRate = interestRate;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Account [account_no=" + account_no + ", customer_id=" + customer_id + ", account_type=" + account_type
				+ ", balance=" + balance + ", interestRate=" + interestRate + "]";
	}

}
