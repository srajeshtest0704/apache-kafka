package com.boa.training.serializer;

import org.apache.kafka.common.serialization.Serializer;

import com.boa.training.domain.Account;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AccountSerializer implements Serializer<Account> {

	private ObjectMapper mapper = new ObjectMapper();

	@Override
	public byte[] serialize(String topic, Account account) {

		byte[] array = null;

		try {
			String content = mapper.writeValueAsString(account);
			System.out.println("serializing : " + content);
			System.out.println("serializing with bytes : " + mapper.writeValueAsBytes(account));
			array = content.getBytes();

		} catch (JsonProcessingException e) {
			e.printStackTrace();
			System.err.println("json processing exception");
		}
		return array;
	}

}
