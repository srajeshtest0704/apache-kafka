package com.training.receiver;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;

public class FirstReceiverExampleFromSpecificPartition {

	private static final String TOPIC_NAME = "first-topic";

	public static void main(String[] args) {

		Properties props = new Properties();
		props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		props.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		props.setProperty(ConsumerConfig.GROUP_ID_CONFIG, "test-group");
		// props.setProperty(ConsumerConfig.GROUP_ID_CONFIG, args[0]);

		List<TopicPartition> partitionList = new ArrayList<TopicPartition>();
		TopicPartition partition = new TopicPartition(TOPIC_NAME, Integer.parseInt(args[0]));
		partitionList.add(partition);

		KafkaConsumer<String, String> kafkaConsumer = new KafkaConsumer<String, String>(props);
		kafkaConsumer.assign(partitionList);

		try {
			while (true) {
				ConsumerRecords<String, String> consumerRecords = kafkaConsumer.poll(Duration.ofSeconds(5));
				for (ConsumerRecord<String, String> record : consumerRecords) {
					System.out.println("partition: " + record.partition() + " key: " + record.key() + " payload:"
							+ record.value());
				}
			}
		} finally {
			kafkaConsumer.close();
		}
	}

}
