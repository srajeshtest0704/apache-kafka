package com.boa.training.domain;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Account {

	private int accNo;
	private int customerId;
	private String accType;

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public Account(int accNo, int customerId, String accType) {
		super();
		this.accNo = accNo;
		this.customerId = customerId;
		this.accType = accType;
	}

	public Account() {
		super();
	}

}
