package com.boa.training.partitioner;

import java.util.Map;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

import com.boa.training.domain.Account;

public class AccountPartitioner implements Partitioner {

	@Override
	public void configure(Map<String, ?> configs) {
		System.out.println("configure the partitioner");
	}

	@Override
	public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
		Account account = (Account) value;
		int partition = 3;
		if ("SB".equals(account.getAccType())) {
			partition = 0;
		} else if ("LA".equals(account.getAccType())) {
			partition = 1;
		} else if ("CA".equals(account.getAccType())) {
			partition = 2;
		}
		System.out.println("message send to partition : " + partition);
		return partition;
	}

	@Override
	public void close() {
		System.out.println("closed the partitioner");
	}

}
