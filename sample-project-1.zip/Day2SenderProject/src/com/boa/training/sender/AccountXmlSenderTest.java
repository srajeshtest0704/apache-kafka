package com.boa.training.sender;

import java.io.File;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import com.boa.training.domain.Account;
import com.boa.training.partitioner.AccountPartitioner;
import com.boa.training.serializer.AccountSerializer;

public class AccountXmlSenderTest {

	private static final String TOPIC_NAME = "account-topic";

	public static void main(String[] args) {

		Properties props = new Properties();
		props.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, AccountSerializer.class.getName());
		props.setProperty(ProducerConfig.PARTITIONER_CLASS_CONFIG, AccountPartitioner.class.getName());

		KafkaProducer<String, Account> kafkaProduer = new KafkaProducer<String, Account>(props);

		Account account = readFromFile();
		ProducerRecord<String, Account> producerRecord = new ProducerRecord<String, Account>(TOPIC_NAME, "sb", account);
		kafkaProduer.send(producerRecord);

		kafkaProduer.close();

	}

	public static Account readFromFile() {
		Account account = null;

		try {
			JAXBContext context = JAXBContext.newInstance(Account.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			account = (Account) unmarshaller.unmarshal(new File("account.xml"));
		} catch (Exception e) {
		}
		return account;
	}

}
