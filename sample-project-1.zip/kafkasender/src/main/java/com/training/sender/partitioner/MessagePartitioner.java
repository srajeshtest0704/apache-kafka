package com.training.sender.partitioner;

import java.util.Map;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

public class MessagePartitioner implements Partitioner {

	public void configure(Map<String, ?> configs) {
		System.out.println("configuring the partitioner");
	}

	public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
		String msgKey = (String) key;
		int partition = 3;
		if (msgKey.equals("first-msg")) {
			partition = 0;
		} else if (msgKey.equals("second-msg")) {
			partition = 1;
		} else if (msgKey.equals("third-msg")) {
			partition = 2;
		}
		return partition;
	}

	public void close() {
		System.out.println("closed the partitioner");
	}

}
