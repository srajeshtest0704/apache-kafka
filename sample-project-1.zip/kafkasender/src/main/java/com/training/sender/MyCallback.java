package com.training.sender;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.RecordMetadata;

public class MyCallback implements Callback {

	private String key;

	public MyCallback(String key) {
		super();
		this.key = key;
	}

	public void onCompletion(RecordMetadata metadata, Exception exception) {

		if (exception == null) {
			System.out.println("Message with key : " + key + " delivered to partition : " + metadata.partition()
					+ " offset : " + metadata.offset());
		}
	}

}
