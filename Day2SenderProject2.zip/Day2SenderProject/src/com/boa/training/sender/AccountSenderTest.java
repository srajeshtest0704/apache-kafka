package com.boa.training.sender;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import com.boa.training.domain.Account;
import com.boa.training.partitioner.AccountPartitioner;
import com.boa.training.serializer.AccountSerializer;

public class AccountSenderTest {

	private static final String TOPIC_NAME = "account-topic";

	public static void main(String[] args) {

		Properties props = new Properties();
		props.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, AccountSerializer.class.getName());
		props.setProperty(ProducerConfig.PARTITIONER_CLASS_CONFIG, AccountPartitioner.class.getName());

		KafkaProducer<String, Account> kafkaProduer = new KafkaProducer<String, Account>(props);

		int customerId = 1001;
		for (int i = 1001; i <= 1010; i++) {
			Account account = new Account(i, customerId, "SB");
			ProducerRecord<String, Account> producerRecord = new ProducerRecord<String, Account>(TOPIC_NAME, "sb",
					account);
			kafkaProduer.send(producerRecord);
			customerId++;
		}

		customerId = 2001;
		for (int i = 2001; i <= 2010; i++) {
			Account account = new Account(i, customerId, "LA");
			ProducerRecord<String, Account> producerRecord = new ProducerRecord<String, Account>(TOPIC_NAME, "la",
					account);
			kafkaProduer.send(producerRecord);
			customerId++;
		}

		customerId = 3001;
		for (int i = 3001; i <= 3010; i++) {
			Account account = new Account(i, customerId, "CA");
			ProducerRecord<String, Account> producerRecord = new ProducerRecord<String, Account>(TOPIC_NAME, "ca",
					account);
			kafkaProduer.send(producerRecord);
			customerId++;
		}

		kafkaProduer.close();

	}

}
