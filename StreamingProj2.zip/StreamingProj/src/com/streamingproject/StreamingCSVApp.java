package com.streamingproject;

import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes.StringSerde;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;

import com.boa.training.domain.Account;
import com.boa.training.serde.AccountSerde;

public class StreamingCSVApp {
	public static void main(String[] args) {

		Properties props = new Properties();
		props.setProperty(StreamsConfig.APPLICATION_ID_CONFIG, "account_transform_interest_rate_app");
		props.setProperty(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, StringSerde.class.getName());
		props.setProperty(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, AccountSerde.class.getName());
		props.setProperty(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");

		StreamsBuilder builder = new StreamsBuilder();
		KStream<String, Account> srcStream = builder.stream("topic-mysql-apache-kafka14-account");
		KStream<String, String> targetStream = srcStream.mapValues(account -> {
			Account acc = new Account();
			acc.setAccount_no(account.getAccount_no());
			acc.setCustomer_id(account.getCustomer_id());
			acc.setAccount_type(account.getAccount_type());
			acc.setBalance(account.getBalance());
			double interestRate = 0;
			if (account.getAccount_type().equals("SB")) {
				interestRate = 5.2;
			} else if (account.getAccount_type().equals("RD")) {
				interestRate = 7.4;
			}
			if (account.getAccount_type().equals("CA")) {
				interestRate = 0;
			}
			acc.setInterestRate(interestRate);
			return "\"" + acc.getAccount_no() + "," + acc.getCustomer_id() + "," + acc.getBalance() + ","
					+ acc.getInterestRate() + "\"";
		});
		targetStream.to("topic-interest-rate-csv", Produced.valueSerde(new StringSerde()));
		KafkaStreams streams = new KafkaStreams(builder.build(), props);
		streams.start();

	}

}
