package com.boa.training.serde;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import com.boa.training.deserializer.AccountDeserializer;
import com.boa.training.domain.Account;
import com.boa.training.serializer.AccountSerializer;

public class AccountSerde implements Serde<Account> {

	@Override
	public Deserializer<Account> deserializer() {
		return new AccountDeserializer();
	}

	@Override
	public Serializer<Account> serializer() {
		return new AccountSerializer();
	}

}