package com.boa.training.deserializer;

import org.apache.kafka.common.serialization.Deserializer;

import com.boa.training.domain.Account;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AccountDeserializer implements Deserializer<Account> {

	private ObjectMapper mapper = new ObjectMapper();

	@Override
	public Account deserialize(String topic, byte[] data) {
		System.out.println("deserializing " + new String(data));

		Account account = null;
		try {
			account = mapper.readValue(data, Account.class);
		} catch (Exception e) {
			System.err.println("Error while reading the byte array data");
		}
		System.out.println(account);
		return account;
	}

}
