package com.training.sender;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

public class FirstSender {

	private static final String TOPIC_NAME = "first-topic";

	public static void main(String[] args) {

		Properties props = new Properties();
		props.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.setProperty("security.protocol", "SASL_PLAINTEXT");
		props.setProperty("sasl.mechanism", "PLAIN");

		KafkaProducer<String, String> kafkaProduer = new KafkaProducer<String, String>(props);

		for (int i = 1; i <= 10; i++) {

			ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(TOPIC_NAME, "test-msg",
					"This is a test message : " + i);
			kafkaProduer.send(producerRecord);

		}

		System.out.println("Messages sent");
		kafkaProduer.close();

	}

}
