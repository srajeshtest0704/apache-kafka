package com.training.sender;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import com.training.sender.partitioner.MessagePartitioner;

public class FirstSenderExampleWithCallbackAndPartitioner {

	private static final String TOPIC_NAME = "first-topic";

	public static void main(String[] args) {

		Properties props = new Properties();
		props.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		props.setProperty(ProducerConfig.PARTITIONER_CLASS_CONFIG, MessagePartitioner.class.getName());

		KafkaProducer<String, String> kafkaProduer = new KafkaProducer<String, String>(props);
		MyCallback myCallback1 = new MyCallback("first-msg");
		for (int i = 1; i <= 10; i++) {

			ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(TOPIC_NAME, "first-msg",
					"This is a first message : " + i);
			kafkaProduer.send(producerRecord, myCallback1);

		}

		MyCallback myCallback2 = new MyCallback("second-msg");
		for (int i = 11; i <= 20; i++) {

			ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(TOPIC_NAME, "second-msg",
					"This is a second message : " + i);
			kafkaProduer.send(producerRecord, myCallback2);

		}

		MyCallback myCallback3 = new MyCallback("third-msg");
		for (int i = 21; i <= 30; i++) {

			ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(TOPIC_NAME, "third-msg",
					"This is a third message : " + i);
			kafkaProduer.send(producerRecord, myCallback3);

		}

		MyCallback myCallback4 = new MyCallback("fourth-msg");
		for (int i = 31; i <= 40; i++) {

			ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(TOPIC_NAME, "fourth-msg",
					"This is a fourth message : " + i);
			kafkaProduer.send(producerRecord, myCallback4);

		}

		MyCallback myCallback5 = new MyCallback("fifth-msg");
		for (int i = 41; i <= 50; i++) {

			ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(TOPIC_NAME, "fourth-msg",
					"This is a fifth-msg message : " + i);
			kafkaProduer.send(producerRecord, myCallback5);

		}

		System.out.println("Messages sent");
		kafkaProduer.close();

	}

}
